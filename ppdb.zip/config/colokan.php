<?php
$host = "localhost";
$dbuser = "root";
$dbpasswd = "";
$database = "ppdb_miululalbaab";

$colok = mysqli_connect($host, $dbuser, $dbpasswd, $database);
?>
