<?php
####db configuration
$dbhost			= "localhost";
$dbuser			= "root";
$dbpass			= "";
$dbname			= "db_tutorial";
$dbtype			= "mysql";
?>