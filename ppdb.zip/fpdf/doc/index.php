<?php
//--Silent is the best ;-) ---
?>